#!/usr/bin/env bash
set -u
BIN=./llama.cpp/build/bin/llama-bench
MODEL=models/Qwen_Qwen3.6-35B-A3B-Q4_K_M.gguf
OUT=results/placement
mkdir -p "$OUT"
for N in 30 20 10 0; do
  NAME=ncmoe_${N}
  echo "=== $NAME $(date -Is) ==="
  "$BIN" -m "$MODEL" -p 20480 -n 512 -r 1 -t 6 -ngl 99 -ncmoe "$N" -fa on -b 2048 -ub 512 -o jsonl > "$OUT/$NAME.jsonl" 2> "$OUT/$NAME.log" || echo $? > "$OUT/$NAME.exit"
done
