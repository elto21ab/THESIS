#!/usr/bin/env bash
set -u
BIN=./llama.cpp/build/bin/llama-bench; MODEL=models/Qwen_Qwen3.6-35B-A3B-Q4_K_M.gguf; OUT=results/continued; mkdir -p "$OUT"
run(){ name=$1; shift; [ -s "$OUT/$name.jsonl" ] && return; echo "=== $name $(date -Is)"; "$BIN" -m "$MODEL" -p 20480 -n 512 -r 1 -t 6 -ngl 99 -fa on -b 2048 -o jsonl "$@" > "$OUT/$name.jsonl" 2> "$OUT/$name.log" || echo $? > "$OUT/$name.exit"; }
run ncmoe_5_ub512 -ncmoe 5 -ub 512
run ncmoe_7_ub512 -ncmoe 7 -ub 512
# ubatch around known safe ncmoe=10; later use boundary winner if enough time
run ncmoe_10_ub256 -ncmoe 10 -ub 256
run ncmoe_10_ub1024 -ncmoe 10 -ub 1024
run ncmoe_10_ub512_t4 -ncmoe 10 -ub 512 -t 4
# llama-bench defaults except explicit workload/model/reps. Captures automatic/default placement.
echo "=== defaults $(date -Is)"; "$BIN" -m "$MODEL" -p 20480 -n 512 -r 1 -o jsonl > "$OUT/defaults.jsonl" 2> "$OUT/defaults.log" || echo $? > "$OUT/defaults.exit"
