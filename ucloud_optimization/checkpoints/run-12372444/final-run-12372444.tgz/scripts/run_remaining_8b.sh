#!/usr/bin/env bash
set -Eeuo pipefail
cd /work/LCPP_OffloadTesting
PY=venvs/tuner/bin/python
remaining=$(( $(date -d "2026-08-23 16:45:00" +%s) - $(date +%s) ))
(( remaining > 300 )) || exit 0
mkdir -p runs/resource
(while :; do printf "%s " "$(date -Is)"; awk /'MemTotal|MemAvailable/ {printf "%s=%s ",$1,$2}' /proc/meminfo; printf "cpu_load="; cut -d" " -f1-3 /proc/loadavg; nvidia-smi --query-gpu=power.draw,temperature.gpu,temperature.memory,clocks.current.graphics,clocks.current.memory --format=csv,noheader,nounits 2>/dev/null || true; sleep 1; done) > runs/resource/reasoning.csv & MON=$!
trap 'kill $MON 2>/dev/null || true' EXIT
# Hard deadline protects final export window.
timeout --signal=INT --kill-after=30 "$remaining" "$PY" tools/tune_inference.py serve-bench \
 --config configs/lfm25-8b-reasoning.toml --engine llama.cpp --concurrency 1 2 4 \
 --prompts data/V7_mixed16_reasoning.jsonl --limit 16 \
 > runs/reasoning-driver.log 2>&1 || true
kill $MON 2>/dev/null || true; wait $MON 2>/dev/null || true
trap - EXIT
sha256sum runs/lfm25-8b-reasoning/server/* > runs/lfm25-8b-reasoning/SHA256SUMS 2>/dev/null || true
tar czf runs/checkpoint-$(date +%Y%m%d-%H%M).tgz runs configs manifests docs tools scripts data/V7_mixed16_*.jsonl
